package com.presidio.Rentify_Backend.entity;

public enum Role {
    BUYER,
    SELLER
}
