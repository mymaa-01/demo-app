package com.presidio.Rentify_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentifyBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(RentifyBackendApplication.class, args);
	}

}
