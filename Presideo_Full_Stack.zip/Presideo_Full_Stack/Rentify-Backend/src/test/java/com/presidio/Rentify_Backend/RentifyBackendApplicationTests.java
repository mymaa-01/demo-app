package com.presidio.Rentify_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentifyBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
